## Meopasl
This is web-game inspired by homm и disciples.

## Current state
Under development.

---
Developes as a lab at ITMO University.
